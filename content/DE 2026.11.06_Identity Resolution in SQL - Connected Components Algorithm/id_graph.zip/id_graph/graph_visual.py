import networkx as nx
import matplotlib.pyplot as plt
from google.cloud import bigquery
# Set up BigQuery client
client = bigquery.Client()

# Define the SQL query
QUERY = """
WITH
  components AS (
  SELECT
    *
  FROM
    `project_id.dataset_id.base_identity_resolution__graph`
  QUALIFY
    COUNT(component_id) OVER (PARTITION BY component_id) > 5
  ORDER BY
    component_id
  LIMIT
    50),
  edges AS (
  SELECT
    e.source_node,
    e.target_node
  FROM
    `project_id.dataset_id.base_identity_resolution__edges` AS e
  INNER JOIN
    components AS c
  ON
    e.source_node = c.node_id
)
SELECT
  *
FROM
   edges
"""

# Execute the query and convert the result to a pandas DataFrame
df = client.query(QUERY).to_dataframe()

# Create a graph from the DataFrame
G = nx.from_pandas_edgelist(df, source='source_node', target='target_node')

# Draw the graph
plt.figure(figsize=(10, 7))
pos = nx.spring_layout(G)
nx.draw(G, pos, with_labels=True, node_size=500, node_color='skyblue',
        font_size=12, font_color='grey', font_weight='light', edge_color='grey')
plt.show()