with
    orders_email_client_id as (
        select
            email as source_node,
            'email' as source_type,
            ga4_client_id as target_node,
            'ga4_client_id' as target_type
        from {{ ref("stg__orders") }}
    ),

    form_submits_email_client_id as (
        select
            email as source_node,
            'email' as source_type,
            ga4_client_id as target_node,
            'ga4_client_id' as target_type
        from {{ ref("stg__form_submits") }}
    ),

    unioned as (
        select * from orders_email_client_id
        union all
        select * from form_submits_email_client_id
    ),

    reversed as (
        select * from unioned
        union all
        select
            target_node as source_node,
            target_type as source_type,
            source_node as target_node,
            source_type as target_type
        from unioned
    ),

    final as (
        select distinct *, {{ dbt_utils.generate_surrogate_key(["source_node", "target_node"])}} as id
        from reversed
    )

select * from final