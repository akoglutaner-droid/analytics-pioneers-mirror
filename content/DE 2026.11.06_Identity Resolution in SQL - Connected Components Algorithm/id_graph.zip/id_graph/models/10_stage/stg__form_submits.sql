with
    source as (
        select * from {{ source("web", "form_submits") }}
    ),

    final as (
        select
            submit_id,
            email,
            cast(ga4_client_id as string) as ga4_client_id
        from source
    )

select * from final